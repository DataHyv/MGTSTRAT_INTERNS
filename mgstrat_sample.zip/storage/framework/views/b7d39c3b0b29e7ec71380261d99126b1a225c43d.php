
<div class="card-header">
    <h4 class="card-title">Information</h4>
</div>
<div class="form-body container">
    <div class="form-group row">
        <div class="col-md-4">
            <label>Full Name</label>
        </div>
        
        <div class="col-md-8">
            <div class="form-group has-icon-left">
                <div class="position-relative">
                    <input type="text" class="form-control <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('fullName')); ?>" placeholder="Enter full name" id="first-name-icon"
                        name="fullName"></input>
                    <div class="form-control-icon">
                        <i class="fa-solid fa-user"></i>
                    </div>
                    <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <label>Engagement Type</label>
        </div>
        <div class="col-md-8">
            <div class="form-group has-icon-left">
                <div class="position-relative">
                    <fieldset class="form-group">
                        <select class="form-select <?php $__errorArgs = ['engagement_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="engagement_type" id="engagement_type" value="<?php echo e(old('engagement_type')); ?>">
                            <option selected disabled>-- Select Engagement Type --</option>
                            <option value="Strategy" <?php echo e(old('engagement_type') == 'Strategy' ? 'selected="selected"' : ''); ?>>Strategy</option>
                            <option value="Leadership" <?php echo e(old('engagement_type') == 'Leadership' ? 'selected="selected"' : ''); ?>>Leadership</option>
                            <option value="Teams" <?php echo e(old('engagement_type') == 'Teams' ? 'selected="selected"' : ''); ?>>Teams</option>
                            <option value="Capability" <?php echo e(old('engagement_type') == 'Capability' ? 'selected="selected"' : ''); ?>>Capability</option>
                        </select>
                        <div class="form-control-icon">
                            <i class="fa-solid fa-bars-staggered"></i>
                        </div>
                        <?php $__errorArgs = ['engagement_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <label>Webinar Title</label>
        </div>
        <div class="col-md-8">
            <div class="form-group has-icon-left">
                <div class="position-relative">
                    <fieldset class="form-group">
                        <select class="form-select <?php $__errorArgs = ['webinar_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="webinar_title"
                            id="webinar_title">
                            <option selected disabled>-- Select Webinar Title --</option>
                            <option value="Re:Think Mental Wellness" <?php echo e(old('webinar_title') == 'Re:Think Mental Wellness' ? 'selected="selected"' : ''); ?> >Think Mental
                                Wellness
                            </option>
                            <option value="Making Emotional Intelligence Visible" <?php echo e(old('webinar_title') == 'Making Emotional Intelligence Visible' ? 'selected="selected"' : ''); ?>>Making
                                Emotional Intelligence Visible
                            </option>
                            <option value="From Burnout to Balance" <?php echo e(old('webinar_title') == 'From Burnout to Balance' ? 'selected="selected"' : ''); ?>>From Burnout to Balance
                            </option>
                            <option value="Power of Yet" <?php echo e(old('webinar_title') == 'Power of Yet' ? 'selected="selected"' : ''); ?>>Power of Yet</option>
                            <option value="Leading Virtual Teams" <?php echo e(old('webinar_title') == 'Leading Virtual Teams' ? 'selected="selected"' : ''); ?>>Leading Virtual Teams
                            </option>
                            <option value="Secret Ingredient to High Performing Teams" <?php echo e(old('webinar_title') == 'Secret Ingredient to High Performing Teams' ? 'selected="selected"' : ''); ?>>
                                Secret Ingredient to High Performing Teams</option>
                            <option value="Creating Digital Bonds" <?php echo e(old('webinar_title') == 'Creating Digital Bonds' ? 'selected="selected"' : ''); ?>>Creating Digital Bonds
                            </option>
                        </select>
                        <div class="form-control-icon">
                            <i class="fa-solid fa-display"></i>
                        </div>
                        <?php $__errorArgs = ['webinar_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>
            </div>
        </div>

        <h6 class="text-center">Dates Covered by Engagement</h3>
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <div class="position-relative">
                        <input type="number" class="form-control <?php $__errorArgs = ['pax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('pax_number')); ?>" placeholder="Number of Pax" name="pax_number" id="pax_number">
                        <div class="form-control-icon">
                            <i class="fa-solid fa-users"></i>
                        </div>
                        <?php $__errorArgs = ['pax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <div class="position-relative">
                        <input type="date" class="form-control <?php $__errorArgs = ['doe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('doe')); ?>" placeholder="Enter Date" name="doe" id="doe">
                        <div class="form-control-icon">
                            <i class="bi bi-calendar"></i>
                        </div>
                        <?php $__errorArgs = ['doe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <div class="position-relative">
                        <input type="time" class="form-control <?php $__errorArgs = ['dot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('dot')); ?>" placeholder="Enter Time" name="dot">
                        <div class="form-control-icon">
                            <i class="bi bi-clock"></i>
                        </div>
                        <?php $__errorArgs = ['dot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mgstrat_sample\resources\views/form/components/information.blade.php ENDPATH**/ ?>