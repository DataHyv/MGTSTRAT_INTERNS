<hr>
<div class="card-header">
    <h4 class="card-title">Engagement Cost</h4>
</div>
<div class="form-body container">
    <h5 class="mt-5">Commision</h5>
    <div class="ml-2" style="margin-left: 1%">
        <div class="form-group row">
            <div class="col-md-4">
                <label class="fw-bold">Sales</label>
                <div class="form-group position-relative has-icon-left">
                    <fieldset>
                        <select class="form-select engagement-cost <?php $__errorArgs = ['ec_sales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ec_sales" id="ec-sales" title="Search title or description...">
                            <option selected disabled>-- Select Sales Value --</option>
                            <optgroup>
                                <option value="0" <?php echo e(old('ec_sales') == '0' ? 'selected="selected"' : ''); ?>>0% </option>
                            </optgroup>

                            <optgroup label="For large engagements, with EMs:">
                                <option value="4" <?php echo e(old('ec_sales') == '4' ? 'selected="selected"' : ''); ?>>4% </option>
                                <option value="6" <?php echo e(old('ec_sales') == '6' ? 'selected="selected"' : ''); ?>>6% </option>
                            </optgroup>

                            <optgroup label="For regular engagements:">
                                <option value="5" <?php echo e(old('ec_sales') == '5' ? 'selected="selected"' : ''); ?>>5% </option>
                                <option value="7" <?php echo e(old('ec_sales') == '7' ? 'selected="selected"' : ''); ?>>7% </option>
                            </optgroup>

                        </select>
                        
                        <?php $__errorArgs = ['ec_sales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <label class="fw-bold">Referral</label>
                <div class="form-group position-relative has-icon-left">
                    <fieldset>
                        <select class="form-select engagement-cost <?php $__errorArgs = ['ec_refferal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ec_refferal" id="ec-refferal">
                            <option selected disabled>-- Select Referral Value --</option>
                            <option value="2" <?php echo e(old('ec_refferal') == '2' ? 'selected="selected"' : ''); ?>>
                                2%</option>
                            <option value="3" <?php echo e(old('ec_refferal') == '3' ? 'selected="selected"' : ''); ?>>
                                3%</option>
                            <option value="10" <?php echo e(old('ec_refferal') == '10' ? 'selected="selected"' : ''); ?>>
                                10%</option>
                        </select>
                        
                        <?php $__errorArgs = ['ec_refferal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <label class="fw-bold">Engagement Manager</label>
                <div class="form-group position-relative has-icon-left">
                    <fieldset>
                        <select class="form-select engagement-cost <?php $__errorArgs = ['ec_engagementManager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ec_engagementManager" id="ec-engagementManager">
                            <option selected disabled>-- Select Engagement Manager Value --</option>
                            <option value="0" <?php echo e(old('ec_engagementManager') == '0' ? 'selected="selected"' : ''); ?>>
                                0%</option> 
                            <option value="4" <?php echo e(old('ec_engagementManager') == '4' ? 'selected="selected"' : ''); ?>>
                                4%</option>
                        </select>
                        
                        <?php $__errorArgs = ['ec_engagementManager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Customization Fee</label>
                    <div class="position-relative">
                        <input type="number" class="form-control custom-fee <?php $__errorArgs = ['ec_customFee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('ec_customFee')); ?>" placeholder="Enter Number of Sessions" id="ec-customFee"
                            name="ec_customFee">
                        
                        <?php $__errorArgs = ['ec_customFee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Number of Hours</label>
                    <div class="form-group position-relative has-icon-left">
                        <fieldset>
                            <select class="form-select custom-hours <?php $__errorArgs = ['ec_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="ec_hours" id="ec-hours">
                                <option selected disabled>-- Select Number of Hours --</option>
                                <option value="0" <?php echo e(old('ec_hours') == '0' ? 'selected="selected"' : ''); ?>>
                                    0</option>
                                <option value="2" <?php echo e(old('ec_hours') == '2' ? 'selected="selected"' : ''); ?>>
                                    2</option>
                            </select>
                            
                            <?php $__errorArgs = ['ec_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Creators Fees</label>
                    <div class="position-relative">
                        <fieldset class="form-group">
                            <select class="form-select creators-fees <?php $__errorArgs = ['ec_creatorsFee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> select"
                                name="ec_creatorsFee" id="ec-creatorsFee" onclick="input_discount()">
                                <option selected disabled>-- Select Creators Fees --</option>
                                <option value="0">
                                    &#8369;0</option>
                                <option value="500" <?php echo e(old('ec_creatorsFee') == '500' ? 'selected="selected"' : ''); ?>>
                                    &#8369;500</option>
                                <option value="1000" <?php echo e(old('ec_creatorsFee') == '1000' ? 'selected="selected"' : ''); ?>>
                                    &#8369;1,000</option>
                            </select>
                            
                            <?php $__errorArgs = ['ec_creatorsFee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Number of Hours</label>
                    <div class="form-group position-relative has-icon-left">
                        <fieldset>
                            <input type="text" class="form-control creator-hour <?php $__errorArgs = ['creators_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="creators_hours"
                                value="<?php echo e(old('creators_hours')); ?>" id="creators-hours" onkeyup="myFunction()">
                            
                            <?php $__errorArgs = ['creators_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <h5 class="mt-5">Program</h5>
    <div class="mb-3" style="margin-left:1%">
        <div class="form-group row">
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Lead</label>
                    <div class="position-relative">
                            <input type="number" class="form-control program-lead <?php $__errorArgs = ['ec_lead'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> select"
                                value="<?php echo e(old('ec_lead')); ?>" name="ec_lead" id="ec-lead">
                            
                            <?php $__errorArgs = ['ec_lead'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Number of Hours</label>
                    <div class="form-group position-relative has-icon-left">
                            <input type="number" class="form-control lead-hour <?php $__errorArgs = ['lead_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lead_hours"
                                value="<?php echo e(old('lead_hours')); ?>" id="lead-hours">
                            
                            <?php $__errorArgs = ['lead_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Night shift / Weekends / Holidays</label>
                    <div class="form-group position-relative has-icon-left">
                            <input type="number" class="form-control lead-nonovertime  <?php $__errorArgs = ['lead_nonovertime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lead_nonovertime"
                               value="<?php echo e(old('lead_nonovertime')); ?>"  id="lead-nonovertime">
                            
                            <?php $__errorArgs = ['lead_nonovertime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

        </div>

        <div class="form-group row">
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Moderator</label>
                    <div class="position-relative">
                        <fieldset class="form-group">
                            <select class="form-select program-moderator <?php $__errorArgs = ['ec_moderator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> select"
                                name="ec_moderator" id="ec_moderator" onclick="input_discount()">
                                <option selected disabled>-- Select Moderator Price --</option>
                                <option value="750" <?php echo e(old('ec_moderator') == '750' ? 'selected="selected"' : ''); ?>>
                                    &#8369;750</option>
                                <option value="1000" <?php echo e(old('ec_moderator') == '1000' ? 'selected="selected"' : ''); ?>>
                                    &#8369;1,000</option>
                                <option value="1250" <?php echo e(old('ec_moderator') == '1250' ? 'selected="selected"' : ''); ?>>
                                    &#8369;1,250</option>
                            </select>
                            
                            <?php $__errorArgs = ['ec_moderator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Number of Hours</label>
                    <div class="form-group position-relative has-icon-left">
                            <input type="number" class="form-control moderator-hour <?php $__errorArgs = ['moderator_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="moderator_hour"
                            value="<?php echo e(old('moderator_hour')); ?>" id="moderator-hour">
                            
                            <?php $__errorArgs = ['moderator_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Night shift / Weekends / Holidays</label>
                    <div class="form-group position-relative has-icon-left">
                            <input type="number" class="form-control moderator-nonovertime  <?php $__errorArgs = ['moderator_nonovertime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="moderator_nonovertime"
                            value="<?php echo e(old('moderator_nonovertime')); ?>" id="moderator-nonovertime">
                            
                            <?php $__errorArgs = ['moderator_nonovertime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-groum row">
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Producer</label>
                    <div class="position-relative">
                        <input type="number" class="form-control program-producer <?php $__errorArgs = ['ec_producer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('ec_producer')); ?>" placeholder="" id="ec-producer"
                            name="ec_producer">
                        
                        <?php $__errorArgs = ['ec_producer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Number of Hours</label>
                    <div class="form-group position-relative has-icon-left">
                        <fieldset>
                            <input type="text" class="form-control producer-hour <?php $__errorArgs = ['producer_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producer_hour"
                            value="<?php echo e(old('producer_hour')); ?>" id="producer-hour">
                            
                            <?php $__errorArgs = ['producer_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Night shift / Weekends / Holidays</label>
                    <div class="form-group position-relative has-icon-left">
                        <fieldset>
                            <input type="text" class="form-control producer-nonovertime  <?php $__errorArgs = ['producer_nonovertime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producer_nonovertime"
                            value="<?php echo e(old('producer_nonovertime')); ?>" id="producer-nonovertime">
                            
                            <?php $__errorArgs = ['producer_nonovertime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <div class="form-group row">
        <div class="row">
            <div class="col-md-3">
                <div class="form-group has-icon-left">
                    <label class="fw-bold">Program Expenses</label>
                    <div class="position-relative">
                        <div class="input-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['ec_programExpense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="ec_programExpense" value="<?php echo e(old('ec_programExpense')); ?>"
                                id="ec_programExpense" onkeypress="isInputNumber(event)"
                                onkeyup="input_expense(this.value)" min="0" max="100">
                            <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div>
                            <?php $__errorArgs = ['ec_programExpense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-md-3">
            <div class="form-group has-icon-left">
                <label class="fw-bold text-uppercase">Total</label>
                <div class="position-relative">
                    <input type="text" id="total" name="ec_total" value="<?php echo e(old('ec_total')); ?>"
                        class="form-control tot <?php $__errorArgs = ['ec_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                    <div class="form-control-icon">
                        <i class="fa-solid fa-file-invoice-dollar"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<hr>
    <div class="form-body container">
        <div class="form-group row justify-content-center">
            <div class="col-md-3">
                <div class="form-group has-icon-left">
                    <label class="fw-bold text-uppercase">Profit</label>
                    <div class="position-relative">
                        <input type="text" id="profit" name="profit" value="<?php echo e(old('profit')); ?>"
                            class="form-control profit <?php $__errorArgs = ['profit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                        <div class="form-control-icon">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group has-icon-left">
                    <label class="fw-bold text-uppercase">LESS: 35% CONTRIBUTION TO OVERHEAD</label>
                    <div class="position-relative">
                        <input type="text" id="less-percent" name="less_percent" value="<?php echo e(old('less_percent')); ?>"
                            class="form-control less_percent <?php $__errorArgs = ['less_percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                        <div class="form-control-icon">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                    </div>
                </div>
            </div>   
            
            <div class="col-md-3">
                <div class="form-group has-icon-left">
                    <label class="fw-bold text-uppercase">Net Profit</label>
                    <div class="position-relative">
                        <input type="text" id="net-profit" name="net_profit" value="<?php echo e(old('net_profit')); ?>"
                            class="form-control net_profit <?php $__errorArgs = ['net_profit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                        <div class="form-control-icon">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                    </div>
                </div>
            </div>        
        </div>

        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="form-group has-icon-left">
                    <label class="fw-bold text-uppercase">Profit Margin</label>
                    <div class="position-relative">
                        <input type="text" id="profit-margin" name="profit_margin" value="<?php echo e(old('profit_margin')); ?>"
                            class="form-control profit_margin <?php $__errorArgs = ['profit_margin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                        <div class="form-control-icon">
                            <i class="fa-solid fa-file-invoice-dollar"></i>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    </div>

    <div class="col-12 d-flex justify-content-center mt-3">
        <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
        <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
    </div>


<?php /**PATH C:\xampp\htdocs\mgstrat_sample\resources\views/form/components/engmntcost.blade.php ENDPATH**/ ?>